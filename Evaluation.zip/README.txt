* The used datasets in the experimental studies can be found in the "Datasets" folder which includes:

- Yeast datasets: the original Collins, Krogan-core and Krogan-extended, Gavin

- The gold standard reference set of complexes: Reference .txt .

* The "Evaluation" folder includes the methods used to evaluate the method and the resulting predicted complexes based on:

- the number of predicted complexes
- Fscore: the harmonic mean of Recall and Precision
- Precision: the rate of predicted protein complexes that match at least one reference complex 
- Recall: the rate of reference protein complexes that match at least one predicted complex, which is used to assess the quantity of matched reference complexes.  
- ACC: the geometric accuracy
- Sn: the rate of the maximum-sum number of matched proteins to the total number of proteins in the set of reference protein complex.
- PPV: the rate of the maximumsum number of matched proteins to the total matched number of proteins in the set of predicted protein complex. 

To evaluate the "Predicted Complexes.txt" file, its name should be modified to "result.txt" and then it runs as follows:
			
  			python match.py -n ppi_name.txt reference_name.txt result_name.txt


 


 