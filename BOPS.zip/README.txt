"Small protein complex prediction algorithm based on protein-protein interaction network segmentation" IEEE/ACM Transactions on Computational Biology and Bioinformatics (TCBB) The project has been submitted and is under review.

What is the function of the BOPS algorithm?
The BOPS algorithm is designed for protein complexes prediction. The BOPS algorithm can find small protein complexes from the protein protein interaction network to help biological experiments.

How to use BOPS to detect protein complexes in the PPI network?
1)The BOPS algorithm is coded in C++. You can use C++11 or or higher version of the compiler to get the program.
Windows��
g++ BOPS.cpp -o BOPS.exe -std=c++11
Linux:
g++ BOPS.cpp -o BOPS -std=c++11

2) 
Run the BOPS algorithm to get the result as follow:
Windows:
BOPS.exe PPI_file result_file balanced_index cohesion_threshold
Linux:
./BOPS PPI_file result_file balanced_index cohesion_threshold

you can input balanced_index and cohesion_threshold on your own.
Windows:
BOPS.exe PPI_file result_file 1.5 2.0
Linux:
./BOPS PPI_file result_file 1.5 2.0

You can also only use the default value by inputting "d"
Windows:
BOPS.exe PPI_file result_file d d
Linux:
./BOPS PPI_file result_file d d

Developer:
JiaqingLv Dalian University of Technology jiaqinglv@foxmail.com
ZhenYao Dalian University of Technology yaozhen@mail.dlut.edu.cn
BingLiang Dalian University of Technology liangbing@dlut.edu.cn
YijiaZhang Dalian University of Technology zhyj@dlut.edu.cn

Notice:  
Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
Everyone is permitted to copy and distribute verbatim copies
 of this license document, but changing it is not allowed. If you have any question, please feel free to contact us via jiaqinglv@foxmail.com

At last, thanks very much for using BOPS.